datagrid-filter.js
112行：扩展行数据获取，支持多层按.分隔的嵌套结构  modify by gsz20170315
原代码：
var source = row[rule.field];
改后：
var source;
if(rule.field && rule.field.indexOf('.') > -1){
	var fields = rule.field.split('.');
	source = row[fields[0]];
	for(var ii = 1;ii < fields.length;ii++){
		source = source[fields[ii]];
	}
}else{
	source = row[rule.field];
}