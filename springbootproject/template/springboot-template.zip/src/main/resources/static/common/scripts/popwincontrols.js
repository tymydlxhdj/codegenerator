//防止panel/window/dialog组件超出浏览器边界
var yl = yl || {};
yl.onMove = {
	onMove : function(left, top) {
		var l = left;
		var t = top;
		if (l < 1) {
			l = 1;
		}
		if (t < 1) {
			t = 1;
		}
		var width = parseInt($(this).parent().css('width')) + 14;
		var height = parseInt($(this).parent().css('height')) + 14;
		var right = l + width;
		var buttom = t + height;
		var browserWidth = $(window).width();
		var browserHeight = $(window).height();
		if (right > browserWidth) {
			l = browserWidth - width;
		}
		if (buttom > browserHeight) {
			t = browserHeight - height;
		}
		if(t<1) t=1;//防止弹出框初始值超过浏览器边界。
		if(l<1) l=1;
		$(this).parent().css({/* 修正面板位置 */
			left : l,
			top : t
		});
	}
};
$.extend($.fn.dialog.defaults, yl.onMove);
$.extend($.fn.window.defaults, yl.onMove);
$.extend($.fn.panel.defaults, yl.onMove);
//jQuery屏蔽鼠标右键：
$(document).ready(function(){  
    $(document).bind("contextmenu",function(e){   
          return false;   
    });
    
 
});




//jQuery 屏蔽tab键：
$(document).keydown(function(e){ 
	//屏蔽tab键
	if(e.keyCode == "9"){
		e.preventDefault(); 
		return;
	}
//	
	//屏蔽浏览器回退事件  "<--backspace"键   linyu 20150427
        var doPrevent;
        
        // for IE && Firefox
        var varkey = (e.keyCode) || (e.which) || (e.charCode);
        
        if (varkey == 8) {

            var d = e.srcElement || e.target; 

            if (d.tagName.toUpperCase() == 'INPUT' || d.tagName.toUpperCase() == 'TEXTAREA') {

                doPrevent = d.readOnly || d.disabled;

                // for button,radio and checkbox
                if (d.type.toUpperCase() == 'SUBMIT'
                    || d.type.toUpperCase() == 'RADIO'
                    || d.type.toUpperCase() == 'CHECKBOX'
                    || d.type.toUpperCase() == 'BUTTON') {

                    doPrevent = true;
                }
            }
            else {

                doPrevent = true;
            }
        }
        else {

            doPrevent = false;
        }

    if (doPrevent){
    	 e.preventDefault();
    }
	
});

/*增加输入框的tab按键功能*/
$(document).on('keyup', 'input', function(e) {
	if(e.keyCode == 9) { //tab键
		var inputs = $(e.target).parents("form").eq(0).find(":input:visible");
		var idx = inputs.index(e.target);
		if (idx == inputs.length - 1) {
			inputs[0].select();
		} else {
			inputs[idx + 1].focus();
			inputs[idx + 1].select();  
		}
	}
});

