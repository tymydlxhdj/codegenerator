function DateFormat(date,fmt) { //日期和时间的格式化，调用方式 DateFormat(new Date(),'yyyyMMdd hh:mm:ss')
	var o = {
		"M+" : date.getMonth() + 1, // 月份
		"d+" : date.getDate(), // 日
		"h+" : date.getHours(), // 小时
		"m+" : date.getMinutes(), // 分
		"s+" : date.getSeconds(), // 秒
		"q+" : Math.floor((date.getMonth() + 3) / 3), // 季度
		"S" : date.getMilliseconds()	// 毫秒
	};
	if (/(y+)/.test(fmt))
		fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "")
				.substr(4 - RegExp.$1.length));
	for ( var k in o)
		if (new RegExp("(" + k + ")").test(fmt))
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k])
					: (("00" + o[k]).substr(("" + o[k]).length)));
	return fmt;
}
//将timestamp转化为日期
function timestampFormat(timestamp,fmt) {
    return DateFormat(new Date(timestamp),fmt) ;
} 
/**
 * 火狐和ie11对后台返回来的字符串形式日期会有带.0的情况
 * @param value
 * @returns
 */
function formatTime(value)
{
	if(value!=null){
		var regEx = new RegExp("\\.0","gi");
		return value.replace(regEx,"");
	}else{
		return '-';
	}	
}