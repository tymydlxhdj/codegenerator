//控制层返回消息的统一处理
function processReturnMessage(data,operateType){
	var returnMsg ;
	var msgCss = '<div  class="messager-icon messager-error" style="margin-top:60px"></div><div class="text-overflow">';
	var timeout = 0;//超时时间
	if(data == 'illeal input'){
		returnMsg = '用户请求非法或者输入非法！';
	}else{
		if(data.successful){
			returnMsg = operateType + '成功';
		}else{
			returnMsg = data.resultHint;
		}
		if(returnMsg != undefined && returnMsg != null && ''!= returnMsg){
			if(returnMsg.indexOf('成功') > 0){ //后台操作成功，提示信息必须包含成功
				timeout = 2000;//2s后自动关闭
				msgCss = '<div  class="messager-icon messager-success" style="margin-top:60px"></div><div class="text-overflow">';
			}else{
				if (data.successful == false) {// 自定义业务异常处理
					msgCss = '<div  class="messager-icon messager-error" style="margin-top:60px"></div><div class="text-overflow" style="width:180px">';
					returnMsg = returnMsg.replaceAll("#bigdataexception#", "");
				} else if(data.resultCode == 'fail'){
					msgCss = '<div  class="messager-icon messager-error" style="margin-top:60px"></div><div class="text-overflow" style="width:180px">';
				} else {// 未捕获异常处理
					returnMsg = "操作失败，请联系管理员！";
				}
			}
		}else {
			returnMsg = "未知错误，请联系管理员！";
		}
	}
	showMessage(timeout,returnMsg,msgCss);
}

function showMessage(timeout,returnMsg,msgCss){
		$.messager.show({
				title:'提示',
				msg:msgCss+returnMsg+'</div>',
				showType:'slide',
				width:280,
				height:210,
				timeout:timeout,
				style:{
					right:0,
					top:'',
					left:'',
					bottom:-document.body.scrollTop-document.documentElement.scrollTop
				}
			});
}
//session失效后，ajax请求拦截
$.ajaxSetup({  
    contentType : "application/x-www-form-urlencoded;charset=utf-8",
    success:function(data){
    	
    },
    complete : function(xhr, textStatus) {
        //越权
    	var outOfPermission = xhr.getResponseHeader('outOfPermission');
    	if(outOfPermission != null && outOfPermission !='undefined' && outOfPermission == 'outOfPermission'){
    		alert('用户越权访问！');
    		return;	
    	}
    	//session timeout
        var sessionStatus = xhr.getResponseHeader('sessionstate');
        if (sessionStatus == 'timeout') {
        	alert("会话失效！");
        	window.parent.location=  basePath+'../isc/layout/index.jsp';
            return;  
        }
        //校验失败
        var validStatus = xhr.getResponseHeader('validateFailed');
        if(!isEmpty(validStatus)){
        	validStatus = decodeURIComponent(validStatus);//转码
        	 //先清除错误提示的div内容
            $("div[validatorErrorId]").html('');
    		var mes = JSON.parse(validStatus);
    		for(var x in mes){
    			$("div[validatorErrorId="+x+"]").html('<span style="color: red">' + mes[x] + '</span>');
    		}
        }
    }  
});  