//javascript的replaceAll
String.prototype.replaceAll = function(s1, s2) {
	return this.replace(new RegExp(s1, "gm"), s2);
}

/**
 * json串封装成URL的参数字符串
 * 
 * @param obj
 * @returns {String}
 */
function bulidStr(obj) {
	var str = '';
	for ( var key in obj) {
		str += key + '=' + obj[key] + '&';
	}
	str = str.substr(0, str.lastIndexOf('&'));
	return str;
}

/**
 * 字符串是否为空
 * 
 * @param obj
 * @returns {bool}
 * @Description 当参数是以url传参的形式接收，参数不存在的情况为'null'
 */
function isEmpty(obj) {
	// 当数据是数组类型时
	if (obj instanceof Array) {
		return obj == '' || obj == undefined || obj == null || obj == 'null';
	} else {
		// 数据非数组
		return obj === '' || obj == undefined || obj == null || obj == 'null';
	}
}

function StringBuilder(){  
    this.init();  
};  
//初始化StringBuilder类  
StringBuilder.prototype.init = function(){  
    this.array = [];  
};  
//追加数据到StringBuilder类  
StringBuilder.prototype.append = function(element){  
    this.array.push(element);  
};  
//转换成String  
StringBuilder.prototype.toString = function(){  
    return this.array.join("");  
};  