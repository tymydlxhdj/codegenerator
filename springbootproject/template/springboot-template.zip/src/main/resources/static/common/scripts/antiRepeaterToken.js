var isAntiReapterEnable = 1; // 客户端是否启用防重放  0：不启用 1：启用
// 获取密钥
function getAntiRepeaterToken() {
	var url = basePath + 'rest/token/getTokenValue';
	var tokenValue;
	$.ajax({
		url : url,
		type : "POST",
		async : false,
		beforeSend: function(request) {
			var antiUuid = UUID.createUUID();
			antiUuid = antiUuid.replace(/\-/g,"");
            request.setRequestHeader("token", antiUuid);
        },
		success : function(data) {
			tokenValue = data.token;
		},
		error : function(data) {
			processReturnMessage(data);
		}
	});
	return tokenValue;
}

$(document).ajaxSend(function(event, request, settings) {
	if (isAntiReapterEnable == 1) {
		var requestUrl = settings.url;
		if (settings.url == (basePath + 'rest/token/getTokenValue')) {
		} else {
			// 获取防重放token linyu 2017-12-13
			var tokenValue = getAntiRepeaterToken();
			request.setRequestHeader("token", tokenValue);
		}
	}
});



function addTokenToUrl(url) {
	if (isAntiReapterEnable == 1) {
		// 获取防重放token linyu 2017-12-13
		var tokenValue = getAntiRepeaterToken();
		if(url.indexOf('&token=') > -1){
			//存在'&token='，则替换其等号后的token
			url = url.replace(url.substr(url.indexOf("&token=")),"&token="+getAntiRepeaterToken());
		}else if(url.indexOf('?token=') > -1){
			//存在'?token='，则替换其等号后的token
			url = url.replace(url.substr(url.indexOf("?token=")),"?token="+getAntiRepeaterToken());
		}else if(url.indexOf('?') > -1){
			url = url + "&token=" + tokenValue;
		}else{
			url = url + "?token=" + tokenValue;
		}
		
	}
	return url;
}
