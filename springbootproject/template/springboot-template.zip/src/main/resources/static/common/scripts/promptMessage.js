let messageInfo;
//控制层返回消息的统一处理
let returnMessage = (data) => {
	let width="170";
	let returnMsg ;
	let msgCss = `<div class="messager1-icon messager1-error" style="margin-top:30px"></div><div class="message">`;
	let timeout = 3000;//超时时间
	if(data!=null && data!='' && data.status == '300'){
		return ;
	}else if(data == 'illeal input'){
		returnMsg = '用户请求非法或者输入非法！';
	}else{
		//原生信息
		if(data.mes){
			returnMsg = data.mes;
			if(returnMsg.length>5){
				width="250";
			}
		}else{//UAP封装信息
			returnMsg = data.resultHint;
		}
		if(returnMsg){
			returnMsg = returnMsg.replace('异常编码','');
			returnMsg = returnMsg.replace('[','');
			returnMsg = returnMsg.replace(']','');
		}else{
			data.success = undefined;
			returnMsg = "操作失败！";
		}
		//新统一封装
		if(data.success != undefined){
			if(data.success){ //后台操作成功，提示信息必须包含成功
				timeout = 3000;//2s后自动关闭
				msgCss = `<div  class="messager1-icon messager1-success" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
			}else{
				if (returnMsg.indexOf('#bigdataexception#') > -1) {
					returnMsg = returnMsg.replace(/#bigdataexception#/g, "");
				}
				if(data.code!=undefined){
					returnMsg = data.code + ':'+returnMsg;
				}else{
					returnMsg = returnMsg;
				}			
				msgCss = `<div  class="messager1-icon messager1-error" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
			}
		} else if (data.resultCode != undefined) {
			if(data.resultCode == "success"){ //后台操作成功，提示信息必须包含成功
				timeout = 3000;//2s后自动关闭
				msgCss = `<div  class="messager1-icon messager1-success" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
			}else{
				if (returnMsg.indexOf('#bigdataexception#') > -1) {// 自定义业务异常处理
					msgCss = `<div  class="messager1-icon messager1-error" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
					returnMsg = returnMsg.replace(/#bigdataexception#/g, "");
				} else {// 未捕获异常处理
					returnMsg = "操作失败，请联系管理员！";
				}
			}
		} else {
			if(returnMsg != undefined && returnMsg != null && ''!= returnMsg){
				if(returnMsg.indexOf('成功') > 0){ //后台操作成功，提示信息必须包含成功
					timeout = 3000;//2s后自动关闭
					msgCss = `<div  class="messager1-icon messager1-success" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
				}else{
					if (returnMsg.indexOf('#bigdataexception#') > -1) {// 自定义业务异常处理
						msgCss = `<div  class="messager1-icon messager1-error" style="margin-top:30px"></div><div class="message" style="width:${width}px">`;
						returnMsg = returnMsg.replace(/#bigdataexception#/g, "");
					} else {// 未捕获异常处理
						returnMsg = "操作失败，请联系管理员！";
					}
				}
			}else {
				returnMsg = "未知错误，请联系管理员！";
			}  
		}
	}
	showReturnMessage(timeout,returnMsg,msgCss);
}

/*
 * 显示提示信息
 */
let showReturnMessage = (timeout,returnMsg,msgCss) => {
		if(returnMsg.length>40){
			messageInfo = returnMsg;
			returnMsg = returnMsg.substring(0,40)+'<a href="javascript:void(0)" style="text-decoration:none" onclick="showAllMessage()"><strong>......</strong></a>';
		}
		let randomId = `tip${(new Date()).valueOf()}`;
		let option = {
				        id:randomId,
						title:'提示',
						msg:msgCss+returnMsg+'</div>'
					  }
		appendWindow(option);
		start(randomId);
		let closeTime = setInterval(() => {
			clearInterval(closeTime);
			if(!$('#'+randomId).data('close')){
				start(randomId);
			}
		},timeout);
 }

 /*
  * 追加提示窗口
  */
 let appendWindow = (option) => {
	 let divTip = document.createElement("div");
	 divTip.id = option.id;
	 divTip.innerHTML = `<h1><a href='javascript:void(0)' onclick='start(this)'> X </a>${option.title}</h1><p>${option.msg}</p>`;
	 divTip.style.height = '0px';
	 divTip.style.bottom = '0px';
	 divTip.style.position = 'fixed';
	 document.body.appendChild(divTip);
	 $('#'+option.id).addClass('tip');
 }
 
 /*
  * 窗口开关
  */
 let start = (thisObj) => {
	 let obj;
	 if(typeof thisObj == 'string'){
		 obj = document.getElementById(thisObj);
		 move(obj); 
	 } else {
		 $('#'+thisObj.parentNode.parentNode.id).data('close',true);
		 obj = thisObj.parentNode.parentNode;
		 move(obj); 
	 }
 }
 
 /*
  *上升下降函数 
  */
 let move = (obj) =>{
	 if(!obj){
		 return;
	 }
	 if (parseInt(obj.style.height) == 0) {
		  obj.style.display = "block";
		  let handle = setInterval(() => {
			  if (parseInt(obj.style.height) > 230) {
				   clearInterval(handle);
			   }else{
				   obj.style.height = (parseInt(obj.style.height) + 8).toString() + "px";
			   }
		  	}, 20);
	  } else {
		 let handle = setInterval(() => {
			 if (parseInt(obj.style.height) < 8) {
				   	clearInterval(handle);
			   		obj.style.display = "none";
			   		$('#'+obj.id).remove();
			   } else {
				   	obj.style.height = (parseInt(obj.style.height) - 8).toString() + "px";
			   }
		 	}, 20);
	  }
 }
 
//显示详细信息 
let showAllMessage = () => {
		$(document.body).append(`<div id="moreMesWindow" modal="true" shadow="false" minimizable="false" cache="false" maximizable="false" collapsible="false" resizable="false"  style="margin: 0px;padding: 0px;overflow: auto;"></div>`)
		$('#moreMesWindow').window({
			title : '详细信息',
		    width:600,    
		    height:400,    
		    modal:true,
		    resizable:true,
		    closable:true,
		    content:messageInfo
		}); 
	}
 
 
 

