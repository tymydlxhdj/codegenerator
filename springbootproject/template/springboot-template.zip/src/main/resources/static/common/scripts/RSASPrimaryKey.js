//获取密钥
function getRsaPrimaryKey(encryptType){
	var url = basePath + 'rest/rsa/getRsaPrimaryKey';
	var encodeKey;
	//提交ajax请求
	$.ajax({
		url : url,
		type : "POST",
		async: false,
		data:{encryptType:encryptType},
		success : function(data) {
			//操作完成后对表格进行刷新
    		//弹出返回消息
			 var object = data.privateKeyMap;
			 var desKey = data.desKey;
	         var modulus = object.modulus, exponent = object.exponent;
             var privateKey = RSAUtils.getKeyPair('', exponent, modulus); //获取私钥
             encodeKey  = RSAUtils.decryptedString(privateKey, desKey); //前端解密
             encodeKey =  encodeKey.split("").reverse().join(""); //解密后是逆序，需要重新排序
             encodeKey = decodeURIComponent(encodeKey);//转码
             if(encryptType == "SMS4"){
            	 encodeKey = hexStr2Byte(encodeKey);
             }
		},
		error:function(data){
//			processReturnMessage(data);
		}
	});
	return encodeKey;  
}
//sms4密钥类型转换
function hexStr2Byte(str)
{
    var dbyte = new Array(str.length / 2);
    for ( var i = 0; i < str.length / 2; i++)
    {
        dbyte[i] = '0x' + str.substr(i * 2, 2);
        if (dbyte[i] < 0)
        {
            dbyte[0] = -1;
            return dbyte;
        }
    }

    return dbyte;
}