//首页面表格宽度、高度
var wholeWidth = window.screen.availWidth - 40;
var wholeHeight = window.screen.availHeight - 310;

// 表格时间列宽度
var dateColumnWidth = 150;

var iscAppId;
var curUserId;
var curUserName;
var curUser;
var curDeptId;
var curDeptName;
var curDept;
var systemState;
var _key = "0f3642e25240457688cccd96ae1561b7";
var sms_key = "0123456789abcdeffedcba9876543210";
/*
 * desc:设置表格列宽的行数
 * param:percent,百分比，例如 0.20 
 */
function fixWidth(percent) {
	return document.body.clientWidth * percent; 
}