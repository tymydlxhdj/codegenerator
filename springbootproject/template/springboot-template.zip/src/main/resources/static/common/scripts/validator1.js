/**
 * 通用的验证工具
 */
$.extend($.fn.validatebox.defaults.rules,{
	customValidator: {
	       validator: function(value,param){    
				var str = decodeURIComponent(param[0]);
		    	$.fn.validatebox.defaults.rules.customValidator.message = param[1];
	    	   	var reg = new RegExp(str);
	    	   	return reg.test(value);
	       },     
	       message: '输入错误'       
	   },
	stringValidator: {
	       validator: function(value,param){    
	    	   var str = decodeURIComponent(param[0]);
		       $.fn.validatebox.defaults.rules.customValidator.message = param[1];
	    	   var reg = new RegExp(str);
	    	   if(value.charAt(value.length-1) == " "){
	    		   //字符串后面含有空格
					return false;
			   }
			   if(value.charAt(0) == " "){
				 //字符串前面含有空格
					return false;
				}
	            return !reg.test(value);  
	       },     
	       message: '请输入合法的字符'     
	   },
	   length:{
		   validator:function(value,param){ 
			   var len=$.trim(value).length; 
		       $.fn.validatebox.defaults.rules.customValidator.message = param[1];
	           return len>=param[0]&&len<=param[1]; 
	       }, 
	           message:"输入内容长度必须介于{0}和{1}之间." 
	   },
	   minLength: {
	       validator: function(value, param){
		       $.fn.validatebox.defaults.rules.customValidator.message = param[1];
	           return value.length >= param[0];
	       },
	       message: '请输入至少{0}个字符.'
	   }
});