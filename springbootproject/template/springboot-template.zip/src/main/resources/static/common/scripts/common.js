//将form的反序列化，并对encodeName字段用 $ESAPI.encoder().encodeForHTM进行处理
function getFormJson(form,encodeName) {
	var o = {};
	var a = $(form).serializeArray();
	$.each(a, function() {
		if (o[this.name] !== undefined) {
			if (!o[this.name].push) {
				o[this.name] = [ o[this.name] ];
			}
			if(this.name == encodeName){
				o[this.name].push($ESAPI.encoder().encodeForHTML(this.value) || '');
			}else{
				o[this.name].push(this.value || '');
			}
		} else {
			if(this.name == encodeName){
				this.value = $ESAPI.encoder().encodeForHTML(this.value);
				o[this.name] = this.value || '';
			}else{
				o[this.name] = this.value || '';
			}
				
		}
	});
	return o;
}
/**
 * 判断是否为IE浏览器(包含IE11)
 * @returns {Boolean}
 */
function isIE() {
//    if (!!window.ActiveXObject || "ActiveXObject" in window)  
//        return true;  
//    else  
//        return false;  
//    
    return !!(navigator.userAgent.indexOf("MSIE ") > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./));
}