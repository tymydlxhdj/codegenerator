/**
 * 通用的验证工具
 */
$.extend($.fn.validatebox.defaults.rules,{
   idcard : {// 验证身份证 
       validator : function(value) { 
           return/^\d{15}(\d{2}[A-Za-z0-9])?$/i.test(value); 
       }, 
       message : '身份证号码格式不正确' 
   },
     minLength: {
       validator: function(value, param){
           return value.length >= param[0];
       },
       message: '请输入至少{0}个字符.'
   },
   onlyLength: {
       validator: function(value, param){
           return value.length == param[0];
       },
       message: '只可输入{0}个字符.'
   },
   length:{validator:function(value,param){ 
       var len=$.trim(value).length; 
           return len>=param[0]&&len<=param[1]; 
       }, 
           message:"输入内容长度必须介于{0}和{1}之间." 
       }, 
   phone : {// 验证电话号码 
       validator : function(value) { 
           return/^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/i.test(value); 
       }, 
       message : '格式不正确,请使用下面格式:020-88888888' 
   }, 
   mobile : {// 验证手机号码 
       validator : function(value) { 
    	   var reg =/^(13|15|18|17)\d{9}$/i;
           return reg.test(value);  
       }, 
       message : '手机号码格式不正确' 
   }, 
   mobiles : {// 验证手机号码 
	   validator : function(value) {
//		   var reg = /(^(13|15|18)\d{9})(,(13|15|18)\d{9})*$/ ;
		   var reg = /^1[358]\d{9}(,1[358]\d{9})*$/ ;
		   return reg.test(value); 
	   }, 
	   message : '手机号码格式不正确' 
   }, 
   emails : {
	   validator : function(value) {
//		   var reg = /^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?$/ ;
		   var reg =  /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+(,([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+)*$/;
		   return reg.test(value); 
	   }, 
	   message : '邮箱格式不正确' 
   }, 
	phoneNum: {// 验证手机号码+固定电话 
       validator : function(value) { 
           return /^(((((010)|(02\d)))[2-8]\d{7})|(0[3-9]\d{2}[2-8]\d{6,7})|(0?(?:147|1[358]\d)\d{8}))$/i.test(value); 
       }, 
       message : '手机号码格式不正确' 
	}, 
   intOrFloat : {// 验证整数或小数 
       validator : function(value) { 
           return /^\d+(\.\d+)?$/i.test(value); 
       }, 
       message : '请输入0到100的数字' 
   }, 
   percentNum : {// 验证整数或小数 
       validator : function(value) { 
    	   var percentNum = value - 0;
    	   var returnValue = true;
    	   if(percentNum > 100){
    		   returnValue = false;
    	   }
           return returnValue; 
       }, 
       message : '请输入数字，并确保格式正确' 
   }, 
   currency : {// 验证货币 
       validator : function(value) { 
           return /^\d+(\.\d+)?$/i.test(value); 
       }, 
       message : '货币格式不正确' 
   }, 
   qq : {// 验证QQ,从10000开始 
       validator : function(value) { 
           return /^[1-9]\d{4,9}$/i.test(value); 
       }, 
       message : 'QQ号码格式不正确' 
   }, 
   integer : {// 验证整数 
       validator : function(value) { 
           return /^[+]?[1-9]+\d*$/i.test(value); 
       }, 
       message : '请输入正整数'
   }, 
   integerRange : {// 验证整数 范围
	   validator : function(value,param) { 
           var num=parseInt($.trim(value)); 
    	   return num>=param[0]&&num<=param[1];
       }, 
       message : "整数必须介于{0}和{1}之间." 
   },
   nonInteger : {// 验证非负整数 
       validator : function(value) { 
    	   var reg = /^(0|[1-9]\d*)$/;  
           return reg.test(value)
       }, 
       message : '请输入非负整数 ' 
   },
   age : {// 验证年龄
       validator : function(value) { 
           return /^(?:[1-9][0-9]?|1[01][0-9]|120)$/i.test(value); 
       }, 
       message : '年龄必须是0到120之间的整数' 
   }, 
   
   chinese : {// 验证中文 
       validator : function(value) { 
           return /^[\Α-\￥]+$/i.test(value); 
       }, 
       message : '请输入中文' 
   },
   chinese2 : {// 验证中文 
       validator : function(value) { 
           return /^[\Α-\￥][\（\Α-\￥\）]$/i.test(value); 
       }, 
       message : '请输入中文' 
   },
   chineseIntOrFloat : {// 验证中文和数字 
       validator : function(value) { 
           return /^[\Α-\￥0-9]+$/i.test(value);
       }, 
       message : '请输入中文或数字' 
   }, 
   english : {// 验证英语 
       validator : function(value) { 
           return /^[A-Za-z]+$/i.test(value); 
       }, 
       message : '请输入英文' 
   },
   english_ : {// 验证英语 及下划线
       validator : function(value) { 
           return /^[a-zA-Z][a-zA-Z_]*$/i.test(value); 
       }, 
       message : '请输入英文或下划线(字母开头)' 
   },
   unnormal : {// 验证是否包含空格和非法字符 
       validator : function(value) { 
           return /.+/i.test(value); 
       }, 
       message : '输入值不能为空和包含其他非法字符' 
   }, 
   username : {// 验证用户名 
       validator : function(value) { 
           return/^[a-zA-Z][a-zA-Z0-9_]{5,15}$/i.test(value); 
       }, 
       message : '用户名不合法（字母开头，允许6-16字节，允许字母数字下划线）' 
   }, 
   dbusername : {// 验证数据库用户名 
       validator : function(value) { 
           return/^[a-zA-Z][a-zA-Z0-9_]{0,15}$/i.test(value); 
       }, 
       message : '用户名不合法（字母开头，允许1-16字节，允许字母数字下划线）' 
   },
   tableNameValidate : {// 验证数据库表名、字段
       validator : function(value) { 
           return/^[a-zA-Z][a-zA-Z0-9_]{0,63}$/i.test(value); 
       }, 
       message : '只允许字母开头,字母+数字+下划线，允许1-64字节' 
   },
   serveip : {// 验证服务ID 
       validator : function(value) { 
           return/^[a-zA-Z][a-zA-Z0-9_@.-]{0,100}$/i.test(value); 
       }, 
       message : '服务ID不合法（字母开头，允许字母数字下划线@和.-）' 
   },
   english_IntOrFloat : {// 验证中英文、_、数字
       validator : function(value) { 
           return/^[a-zA-Z0-9_]+$/i.test(value); 
       }, 
       message : '请输入英文、_、数字' 
   },
   english_IntOrFloatAndChinese : {// 验证英文、_、数字
       validator : function(value) { 
           return/^[a-zA-Z0-9_]{0,128}$/i.test(value) || /^[\Α-\￥0-9]+$/i.test(value) || /^[\Α-\￥_a-zA-X_0-9]+$/i.test(value)|/^[a-zA-X_0-9-.]{0,64}$/i.test(value); 
       }, 
       message : '请输入中英文、_、数字' 
   },
   fiveIntOrFloat : {// 验证小于或等于5位数字
       validator : function(value) { 
           return/^[0-9]{0,5}$/i.test(value); 
       }, 
       message : '请输入小于或等于5位数字' 
   }, 
   englishIntOrFloat : {//验证英文和数字
       validator : function(value) { 
           return/^[a-zA-Z0-9]{0,15}$/i.test(value); 
       }, 
       message : '请输入英文+数字' 
   }, 
   faxno : {// 验证传真 
       validator : function(value) { 
//           return /^[+]{0,1}(\d){1,3}[]?([-]?((\d)|[ ]){1,12})+$/i.test(value); 
           return /^((\(\d{2,3}\))|(\d{3}\-))?(\(0\d{2,3}\)|0\d{2,3}-)?[1-9]\d{6,7}(\-\d{1,4})?$/i.test(value); 
       }, 
       message : '传真号码不正确' 
   }, 
   zip : {// 验证邮政编码 
       validator : function(value) { 
           return /^[1-9]\d{5}$/i.test(value); 
       }, 
       message : '邮政编码格式不正确' 
   }, 
   ip : {// 验证IP地址 
       validator : function(value) { 
    	   var reg = /^((1?\d?\d|(2([0-4]\d|5[0-5])))\.){3}(1?\d?\d|(2([0-4]\d|5[0-5])))$/ ;  
           return reg.test(value)
       }, 
       message : 'IP地址格式不正确' 
   },
   mac:{//验证MAC地址
	   validator : function(value) { 
    	   var reg =/[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}-[A-Fa-f0-9]{2}/;  
    	   var reg1 =/[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}:[A-Fa-f0-9]{2}/;  
           return (value.length == 17) &&(reg.test(value)|reg1.test(value));
       }, 
       message : 'MAC地址格式不正确'
	   
   },
   
   
   name : {// 验证姓名，可以是中文或英文 
           validator : function(value) { 
               return /^[\Α-\￥]+$/i.test(value)|/^\w+[\w\s]+\w+$/i.test(value); 
           }, 
           message : '请输入姓名' 
   },
   partValue: {// 分区值
       validator : function(value) { 
           return /^[a-zA-X_0-9-.]+$/i.test(value); 
       }, 
       message : '请输入拉丁字母或数字，以及“_”、“-”、“.”' 
   },
   english_Int: {// 验证包含拉丁字母或数字，以及“_”、“-”、“.” 
       validator : function(value) { 
           return /^[a-zA-X_0-9-.]{0,15}$/i.test(value); 
       }, 
       message : '请输入拉丁字母或数字，以及“_”、“-”、“.”' 
},
   chineseOrEnglish: {// 验证中文或英文数字 
       validator : function(value) { 
           return /^[\Α-\￥_a-zA-X_0-9]+$/i.test(value)|/^[a-zA-X_0-9-.]{0,64}$/i.test(value); 
       }, 
       message : '请输入中文或英文数字' 
},
   date : {// 验证日期 
       validator : function(value) { 
        //格式yyyy-MM-dd或yyyy-M-d
           return/^(?:(?!0000)[0-9]{4}([-]?)(?:(?:0?[1-9]|1[0-2])\1(?:0?[1-9]|1[0-9]|2[0-8])|(?:0?[13-9]|1[0-2])\1(?:29|30)|(?:0?[13578]|1[02])\1(?:31))|(?:[0-9]{2}(?:0[48]|[2468][048]|[13579][26])|(?:0[48]|[2468][048]|[13579][26])00)([-]?)0?2\2(?:29))$/i.test(value); 
       },
       message : '清输入合适的日期格式'
   },
   msn:{ 
       validator : function(value){ 
       return/^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$/.test(value); 
   }, 
   message : '请输入有效的msn账号(例：abc@hotnail(msn/live).com)' 
   },
   same:{ 
       validator : function(value, param){ 
           if($("#"+param[0]).val() !="" && value != ""){ 
               return $("#"+param[0]).val() == value; 
           }else{ 
               return true; 
           } 
       }, 
       message : '两次输入的密码不一致！'   
   },
   sameByAttr:{ 
       validator : function(value, param){ 
           if($("input["+param[0]+"]").val() !="" && value != ""){ 
               return $("input["+param[0]+"]").val() == value; 
           }else{ 
               return true; 
           } 
       }, 
       message : '两次输入的密码不一致！'   
   },
   wsdl: {     
       validator: function(value){    
            var reg = new RegExp("^(http://|([0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}:[0-9]{1,4}))[/a-zA-Z0-9._%&:=(),?+]*[?]{1}(wsdl|WSDL)$");  
            return reg.test(value);  
       },     
       message: '请输入合法的WSDL地址'     
   },
   httpUrl: {     
       validator: function(value){    
            var reg = new RegExp("^(https?://|([0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}[.]{1}[0-9]{1,3}:[0-9]{1,4}))[/a-zA-Z0-9._%&:=(),?+]*$");  
            return reg.test(value);  
       },     
       message: '请输入合法的HTTP地址'     
   },
   stringValidate: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*()=|{}':;'\\[\\].<>/?~！￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForNotNull: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*()=|{}':;'\\[\\].<>/?~！￥……&*（）——|{}【】‘；：”“'。，、？]|(^(n|N)(u|U)(l|L)(l|L)$)");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForNodeName: {//节点名称  不能包含--   
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*()=|{}':;'\\[\\].<>/?~！￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
		   if(value.indexOf('--') > -1){
			   return false;
		   }
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForReplaceValue: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~!￥$%^&*+=]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*=|{};\\[\\]<>/?~！￥……&*（）——|{}【】‘；：”“。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForSysParams: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*()-+=]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*()=|{}''\\[\\]<>/?~！￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForPath: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&@#*()-+=]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*()=|{}';'\\[\\]<>?~！￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForUrl: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^@#*()-+]");
    	   
    	   var pattern2 = new RegExp("[`~!$^*()|{}';'\\[\\]<>~！￥……*（）——|{}【】‘；：”“'。，、？]");
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForSQL: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~￥$%^@#*]");
    	   
    	   var pattern2 = new RegExp("[~$^*\\[\\]~￥……*]");
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForPWD: {     
       validator: function(value){    
    	   var temp = filterXSS(value);
    	   if(value == temp){
    		   return true;
    	   }
            return false; 
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForFormat: {//数据传输字段格式化函数输入验证     
       validator: function(value){    
    	   var pattern = new RegExp("[~!￥$^&*+=]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*=|{};\\[\\].<>?~！￥……&*（）——|{}【】‘；：”“。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForSpecialSign: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*=|{}':;'\\[\\].<>/?~！￥……&*——|{}【】‘；：”“'、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForHdfs: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^&*-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^&*=|{}':;'\\[\\]<>/?~！￥……&*——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForHive: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!￥$%^*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!$^*()=|{}':'\\[\\]<>~！￥……*（）——{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForHiveComment: {     
       validator: function(value){    
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
		   if(value.indexOf('>') > -1 || value.indexOf('<') > -1){
				 //字符串前面含有空格
				return false;
			}
            return true;  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForRowSeparator: {     
	   validator: function(value){    
		   var pattern = new RegExp("[~'!￥$%^*()-+=:]");
		   
		   var pattern2 = new RegExp("[`~!$^*()=|{}':'\\[\\]<>~！￥……*（）——{}【】‘；：”“'。，、？]");  
		   return !pattern.test(value) && !pattern2.test(value);  
	   },     
	   message: '请输入合法的字符'     
   },
   stringValidateForChinese: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!@#￥$%^&*()-+_=:]");
    	   
    	   var pattern2 = new RegExp("[`~!#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForEngish_: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!@#￥$%^&*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringValidateForCodeTypeOperate: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!@#￥$%^&*()-+=:]");
    	   
    	   var pattern2 = new RegExp("[`~!#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },//用于系统配置》系统数据字典配置》分类配置的添加、修改操作
   checkPort: {  //验证1~65535的端口号
   	validator: function (value,param) {  
   		if(value>65535 || value<1)
   			return false;
   		return /^[0-9]\d{0,4}$/i.test(value);     
   	},  
   		message: '请输入1~65535的端口号'  
   },//用于计算任务→批量计算任务集群参数
   checkCalcParam: {  //验证1~20的参数值
	   	validator: function (value,param) {  
	   		if(value>20 || value<1)
	   			return false;
	   		return /^[0-9]\d{0,4}$/i.test(value);     
	   	},  
	   		message: '请输入1~20的参数值'  
	   },
   //供内部接口服务id输入框验证使用(除了@)
   stringValidateForService: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!#￥$%^&*()+_=:]");  
    	   
    	   var pattern2 = new RegExp("[`~!#$^&*()=|{}':;',\\[\\].<>/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？]");  
    	   
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   stringDescValidate: {     
       validator: function(value){    
    	   var pattern = new RegExp("[%<>=]");
    	   
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   //计算任务-运行参数值验证
   stringValidateForCompute: {     
	    validator: function(value){    
	 	   var pattern = new RegExp("[<>]");  
	 	   if(value.charAt(value.length-1) == " "){
	 		   //字符串后面含有空格
					return false;
			   }
			   if(value.charAt(0) == " "){
				 //字符串前面含有空格
					return false;
				}
	         return !pattern.test(value);  
	    },     
	    message: '请输入合法的字符'     
	},
   //gbase配置参数校验
   stringDescValidateForGbase: {     
       validator: function(value){    
    	   var pattern = new RegExp("[%<>]");
    	   
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   //业务系统字符校验 
   stringSysName: {     
       validator: function(value){    
    	   var pattern = new RegExp("[~'!#￥$%^&*+=:]");  
    	   
    	   var pattern2 = new RegExp("[`~!#$^&*=|{}':;',\\[\\].<>/?~！@#￥……&*——|{}【】‘；：”“'。，、？]");  
    	   
    	   if(value.charAt(value.length-1) == " "){
    		   //字符串后面含有空格
				return false;
		   }
		   if(value.charAt(0) == " "){
			 //字符串前面含有空格
				return false;
			}
            return !pattern.test(value) && !pattern2.test(value);  
       },     
       message: '请输入合法的字符'     
   },
   //不含中文
   noChinese: {     
       validator: function(value){    
    	   var pattern = new RegExp("[\Α-\￥]");
           return !pattern.test(value);  
       },     
       message: '请不要输入中文'     
   },
   secondNumber: {// 超时时间--秒的验证 ,验证零和非零开头的15位数字
       validator : function(value) { 
           return /^(0|[1-9][0-9]{0,14})$/i.test(value); 
       }, 
       message : '请输入小于或等于15位数字' 
   },
   //1到10 的正整数
   oneToTen: {
	   validator: function(value){    
		   var reg = /^(?:[1-9]?|10)$/;
		   return reg.test(value);
       },     
       message: '请输入1-10的数字'   
   },
 //1到4 的正整数
   oneToFour: {
	   validator: function(value){    
		   var reg = /^(?:[1-4]?)$/;
		   return reg.test(value);
       },     
       message: '请输入1-4的数字'   
   },
  //json格式验证
   jsonType : {
	   validator: function(value){  
		   try {
			  JSON.parse(value);
			   return true;
		   } catch(err) {
			   return false;
		   }
       },     
       message: '请输入正确的json格式'  
   },
   //不能全为数字
   noAllNumber: {     
       validator: function(value){    
    	   var reg = /^\d+$/;
    	   return !reg.test(value);
       },     
       message: '不能全为数字'     
   },
   // 验证英文字母或中文打头
   chineseOrEnglishTop: {
	    validator : function(value) { 
	        return /^[\Α-\￥a-zA-Z][\Α-\￥a-zA-Z0-9_]+$/i.test(value)|/^[\Α-\￥a-zA-Z]+$/i.test(value); 
	    }, 
	    message : '请以英文字母或中文打头，仅限输入英文、中文、数字和下划线' 
	},
   
   // 仅限输入数字或英文字母Y、Q、W
   numberOrEnglishYQW: {
	   validator: function(value){    
		   var reg = /^[0-9YQW]*$/g;
		   return value.length<20 && reg.test(value);
       },     
       message: '仅限输入数字或英文字母Y、Q、W' 
	},
   
   // 验证密码规范 
   password : {
       validator : function(value) { 
    	   var pattern = new RegExp('(?=.*[0-9])(?=.*[a-zA-Z])(?=.*[^a-zA-Z0-9]).{8,30}');  
    	   return pattern.test(value);
       }, 
       message:'密码必须由字母、数字、特殊字符组成，长度8~30位' 
   }
});